### Recent Changes Summary — Console Commands & Device Events

| File | What was changed | Issue | Improvement |
|------|------------------|-------|-------------|
| `app/Console/Commands/ApproveDevice.php` | Unified approve/block for one, many, or all pending (`--all`, `--block`, `--create`, `--dry-run`, `--force`) | Four overlapping commands (`approve`, `approve-all`, `bulk-approve`, `block`) | One command covers all approve/block flows |
| `app/Console/Commands/ListDevices.php` | Added `--pending`, `--offline`, `--search`, richer table columns | Separate `list-pending` command; limited filters | Single list command with common filters |
| `app/Console/Commands/ApproveAllDevices.php` | **Removed** | Redundant with unified approve | Use `device:approve --all` |
| `app/Console/Commands/BulkApproveDevices.php` | **Removed** | Redundant | Use `device:approve SN1 SN2 …` |
| `app/Console/Commands/BlockDevice.php` | **Removed** | Redundant | Use `device:approve {serial} --block` |
| `app/Console/Commands/ListPendingDevices.php` | **Removed** | Redundant | Use `device:list --pending` |
| `app/Console/Commands/ShowDevice.php` | Added `declare(strict_types=1)` | Inconsistent style | Aligns with other commands |
| `app/Console/Commands/DeleteDevice.php` | Added `declare(strict_types=1)` | Same | Same |
| `app/Models/Device.php` | `approve()` / `block()` now fire `DeviceApproved` / `DeviceBlocked` | Events only fired from the API controller | Artisan and API share the same domain events |
| `app/Http/Controllers/Api/v1/DeviceController.php` | Removed duplicate `event(...)`; status updates use `approve()` / `block()` | Double-firing events after model change | Single event emission path |

### New command cheatsheet

| Action | Command |
|--------|---------|
| Approve one/many | `php artisan device:approve SN1 SN2` |
| Approve all pending | `php artisan device:approve --all` |
| Block | `php artisan device:approve SN1 --block --reason="…"` |
| List pending | `php artisan device:list --pending` |
| List online/offline | `php artisan device:list --online` / `--offline` |

# End

---
### Recent Changes Summary — Jobs & Events

| File | What was changed | Issue | Improvement |
|------|------------------|-------|-------------|
| `app/Providers/EventServiceProvider.php` | Replaced job classes and `boot()` closures with explicit listener classes in `$listen` | Jobs were registered as listeners but need models in the constructor (broken wiring); attendee logic lived in anonymous closures | Clear, testable event map; correct dispatch path |
| `app/Listeners/DispatchProcessAttendanceLog.php` *(new)* | Thin listener → `ProcessAttendanceLog::dispatch($event->log)` | `ProcessAttendanceLog` could not be built from the event by the container | Reliable attendance processing after `AttendancePunched` |
| `app/Listeners/DispatchDeviceApprovedSideEffects.php` *(new)* | Thin listener → `DeviceApprovedSideEffects::dispatch` | Same constructor/listener mismatch | Side effects run after approve |
| `app/Listeners/DispatchNotifyDeviceOffline.php` *(new)* | Thin listener → `NotifyDeviceOffline::dispatch` | Same mismatch | Offline notifications queued correctly |
| `app/Listeners/DispatchDeviceInfoUpdated.php` *(new)* | Thin listener → `DeviceInfoUpdated` job | Event/job same name; unsafe direct `$listen` entry | Safe bridge; job still aliased correctly |
| `app/Listeners/DispatchProcessAttendeeImportError.php` *(new)* | Thin listener → `ProcessAttendeeImportError::dispatch` | Same mismatch | Import errors processed via queue |
| `app/Listeners/SyncAttendeeOnCreated.php` *(new)* | Replaces closure; skips empty serial lists | Closure-only registration | Explicit, skip no-op dispatches |
| `app/Listeners/SyncAttendeeOnUpdated.php` *(new)* | Replaces closure | Same | Explicit update → device sync |
| `app/Listeners/SyncAttendeeOnDeleted.php` *(new)* | Replaces closure; `delete: true` | Same | Explicit delete → device DELETE commands |
| `app/Listeners/SyncAttendeeOnAccessGranted.php` *(new)* | Replaces closure | Same | Single-device grant sync |
| `app/Listeners/SyncAttendeeOnAccessRevoked.php` *(new)* | Replaces closure; `delete: true` | Same | Single-device revoke |
| `app/Events/AttendeeAccessGranted.php` | `ShouldBroadcast` + payload | No realtime UI update on grant | Broadcasts to `attendees` + `device.{serial}` |
| `app/Events/AttendeeAccessRevoked.php` | `ShouldBroadcast` + payload | No realtime UI update on revoke | Same channels + clear event name |
| `app/Events/AttendeeDeleted.php` | `ShouldBroadcast` + pin/serials payload | Delete was silent to frontends | Clients can refresh lists in realtime |
| `app/Events/AttendeeCreated.php` | Added `declare(strict_types=1)` | Inconsistent typing | Aligns with other events |
| `app/Jobs/DeviceApprovedSideEffects.php` | After-commit, timeout, backoff, tags, logging, `failed()` | Minimal job; weak failure handling | Safer post-approve INFO + attendee re-sync |
| `app/Jobs/SyncAttendeeToDevices.php` | `ShouldBeUnique`, `ShouldQueueAfterCommit`, tags, better logs | Duplicate sync jobs; weak observability | Deduped syncs; clearer success/skip/fail logs |

### Wiring pattern (after change)

| Before | After |
|--------|--------|
| `Event → Job` (broken for model ctors) | `Event → Listener → Job::dispatch(...)` |
| Attendee side effects in `boot()` closures | All in `$listen` + named listeners |
---
# End
---
### Policy Changes Summary

| File | What was changed | Issue | Improvement |
|------|------------------|-------|-------------|
| `app/Policies/Api/v1/Policy.php` | Added class + method docblocks and detailed inline comments explaining `before()`, `authorizeDevice()`, `authorizeSite()`, and `resolveDevice()` | Base policy had almost no documentation; logic for 404 vs 403 and device resolution was opaque | Clear single source of truth for multi-tenancy rules and admin bypass |
| `app/Policies/Api/v1/DevicePolicy.php` | Tightened `view()` with permission check; added full comments | `view()` only checked site access — a user with zero device permissions could still open a device by ID | Permission gate + site gate; admin-only delete documented |
| `app/Policies/Api/v1/PendingCommandPolicy.php` | `viewAny` & `view` now require `canManageCommands()` or `canManageDevices()`; full comments | `viewAny` returned `Response::allow()` unconditionally (too open) | Only users who can manage commands/devices can list or view them |
| `app/Policies/Api/v1/AttendeePolicy.php` | Added comprehensive comments (including `sharesSiteWith()`) | Logic for dual site/device sharing was undocumented | Self-documenting multi-tenancy model for attendees |
| `app/Policies/Api/v1/SitePolicy.php` | Added class + method comments | No explanation of why `viewAny` is open or why delete is admin-only | Clear documentation of sites as the multi-tenant boundary |
| `app/Policies/Api/v1/AttendanceLogPolicy.php` | Replaced hard-coded `isOperator()` with permission checks; added comments | Used role check instead of the permission system | Consistent permission-based authorization |
| `app/Policies/Api/v1/BioTemplatePolicy.php` | Added permission checks on `viewAny` / `view` / `delete`; removed `isOperator()`; added comments | `viewAny` was completely open; delete used hard-coded role | Proper permission gates for biometric data |
| `app/Policies/Api/v1/PhotoPolicy.php` | Same as BioTemplate — permission checks + removed `isOperator()` + comments | `viewAny` was completely open; delete used hard-coded role | Proper permission gates for photos |
| `app/Policies/Api/v1/AttendeeImportErrorPolicy.php` | Added class + method comments | No documentation of resolve/ignore flow | Clear rules for import-error handling |
| `app/Policies/Api/v1/UserPolicy.php` | Added detailed comments for self-protection in `before()` and admin-role guards | Self-lockout prevention and admin-role rules were hard to understand | Explicit documentation of self-protection and elevation rules |
| `routes/api.php` *(new)* | Full reconstructed route list + `throttle:5,1` on login | Routes file was missing from the original ZIP; no rate limiting on login | Complete route map + protection against brute-force login |

### Summary of security improvements

| Issue fixed | Before | After |
|-------------|--------|-------|
| Open `viewAny` policies | PendingCommand, BioTemplate, Photo allowed anyone | Require relevant permissions |
| Hard-coded role checks | `isOperator()` used in several places | Pure permission helpers (`canManage*`, `canRead*`) |
| Missing permission on `Device::view` | Only site check | Permission + site check |
| No login rate limiting | None | `throttle:5,1` |
| Undocumented multi-tenancy logic | Opaque | Inline + docblock comments everywhere |

---

### Recent Changes Summary

| File | What was changed | Issue | Improvement |
|------|------------------|-------|-------------|
| `database/migrations/2026_09_09_034859_create_user_site_table.php` | Table name changed from `site_user` → **`user_site`** | Migration created `site_user`, but `User`, `Site`, and `SiteUser` all expected `user_site` → SQL error on `GET /me` | Pivot table name matches models; `user->sites()` works |
| `app/Models/Device.php` | Added `getRouteKeyName()` returning **`serial_number`** | Route binding looked up devices by UUID; calling `/devices/PSS7234900035` failed with “No query results for model” | URLs use real-world serial numbers: `/devices/{serial}` |
| `bootstrap/app.php` *(new / updated)* | Custom `withExceptions()` renderers for API | Missing models returned full stack traces and exception dumps | Clean JSON:API errors (404, 401, 403, 422, etc.) with short `errors[]` body — no traces to the client |

### Response behavior (after exception fix)

| Situation | Before | After |
|-----------|--------|--------|
| Device serial not found | Full `NotFoundHttpException` + stack trace | `404` + `{ "errors": [{ "status": "404", "title": "Not Found", "detail": "Device [SERIAL] not found." }] }` |
| Validation error | Default Laravel validation JSON | JSON:API-style `errors` with `source.pointer` |
| Unauthenticated | Often HTML or raw exception | `401` + clear message |
| Policy forbidden | Mixed | `403` + policy message |

### Quick reference — what to run on your machine

```bash
# 1. Fix pivot table (if needed)
php artisan migrate

# 2. Device model change is code-only — no migrate
# 3. Merge bootstrap/app.php exception block into your app
# 4. APP_DEBUG=false in production
```
# End

---

### Review summary

| Area | Issue | Improvement applied |
|------|--------|---------------------|
| **Event → Job wiring** | Jobs like `ProcessAttendanceLog` were listed directly in `$listen` but their constructors expect models. Laravel cannot build those jobs from the event. | Thin **Listeners** that call `Job::dispatch(...)` |
| **EventServiceProvider** | Attendee side-effects lived in anonymous `Event::listen` closures in `boot()` | All mappings moved to explicit `$listen` + dedicated listener classes |
| **Access events** | `AttendeeAccessGranted` / `Revoked` did not broadcast | Now `ShouldBroadcast` with useful payload |
| **AttendeeDeleted** | No broadcast | Broadcasts pin + device serials |
| **DeviceApprovedSideEffects** | Minimal; no `failed()`, no timeout, no after-commit | `ShouldQueueAfterCommit`, timeout, tags, logging, `failed()` |
| **SyncAttendeeToDevices** | Could enqueue duplicate work | `ShouldBeUnique` + `ShouldQueueAfterCommit`, clearer logging |

### New listeners (`app/Listeners/`)

| Listener | Event | Dispatches |
|----------|--------|------------|
| `DispatchProcessAttendanceLog` | `AttendancePunched` | `ProcessAttendanceLog` |
| `DispatchDeviceApprovedSideEffects` | `DeviceApproved` | `DeviceApprovedSideEffects` |
| `DispatchNotifyDeviceOffline` | `DeviceOffline` | `NotifyDeviceOffline` |
| `DispatchDeviceInfoUpdated` | `DeviceInfoUpdated` | `DeviceInfoUpdated` job |
| `DispatchProcessAttendeeImportError` | `AttendeeImportErrorCreated` | `ProcessAttendeeImportError` |
| `SyncAttendeeOnCreated` | `AttendeeCreated` | `SyncAttendeeToDevices` |
| `SyncAttendeeOnUpdated` | `AttendeeUpdated` | `SyncAttendeeToDevices` |
| `SyncAttendeeOnDeleted` | `AttendeeDeleted` | `SyncAttendeeToDevices` (delete) |
| `SyncAttendeeOnAccessGranted` | `AttendeeAccessGranted` | `SyncAttendeeToDevices` |
| `SyncAttendeeOnAccessRevoked` | `AttendeeAccessRevoked` | `SyncAttendeeToDevices` (delete) |

### Flow (after change)

```
Event fired
  → Listener (sync, tiny)
    → Job::dispatch(...) on the right queue
      → Worker runs side effects (device commands, notifications, …)
```

### Still optional / TODO in jobs

- `ProcessAttendanceLog` — still mostly a stub (`TODO: late/early, daily summary`)
- `NotifyDeviceOffline` — still has `TODO` for real notification channels

Copy the new `app/Listeners/` files and updated `EventServiceProvider`, jobs, and events into your project, then:

```bash
php artisan event:clear
php artisan queue:restart
# or octane:reload
```


# End
---
| File | Error | Correction |Update|
|---|---|---|---|
| `2026_09_09_034859_create_user_site_table.php` | Created/dropped table `site_user`; filename did not match models | Table is `user_site`; file renamed to `2026_09_09_034859_create_user_site_table.php` ||
| `0001_01_01_000000_create_users_table.php` | `sessions.user_id` was `foreignUuid` but `users.id` is bigint | `foreignId('user_id')->nullable()->index()->constrained('users')->nullOnDelete()` ||
| `UserPolicy.php` | Missing — `UserController` / `UserPermissionController` authorized against `User` with no policy | Added `App\Policies\API\V1\UserPolicy` (self vs `manage-users`; deny self delete/sites/permissions) ||
| `AuthServiceProvider.php` | V1 policies not auto-discovered (`App\Policies\API\V1`) | New provider maps all 9 models → V1 policies ||
| `AttendanceLogController.php` | Namespace `Api\v1`; no resource import; `index()` untyped | Namespace `Api\V1`; import `AttendanceLogResource` + `JsonApiResourceCollection`; typed `index()` ||
| `AttendeeController.php` | Imported `App\Http\Resources\AttendeeResource`; missing collection import | `App\Http\Resources\Api\V1\AttendeeResource` + `JsonApiResourceCollection` ||
| `AttendeeImportErrorController.php` | Wrong resource namespace; missing collection import | `Api\V1\AttendeeImportErrorResource` + `JsonApiResourceCollection` ||
| `AuthController.php` | Imported `App\Http\Resources\UserResource` | `App\Http\Resources\Api\V1\UserResource` ||
| `BioTemplateController.php` | Wrong resource namespace; missing collection import | `Api\V1\BioTemplateResource` + `JsonApiResourceCollection` ||
| `DeviceController.php` | Wrong resource namespace; missing collection import | `Api\V1\DeviceResource` + `JsonApiResourceCollection` ||
| `PendingCommandController.php` | Wrong resource namespace; missing collection import | `Api\V1\PendingCommandResource` + `JsonApiResourceCollection` ||
| `PhotoController.php` | Wrong resource namespace; missing collection import | `Api\V1\PhotoResource` + `JsonApiResourceCollection` ||
| `SiteController.php` | Wrong resource namespace; missing collection import | `Api\V1\SiteResource` + `JsonApiResourceCollection` ||
| `UserController.php` | Wrong resource namespace; missing collection import | `Api\V1\UserResource` + `JsonApiResourceCollection` ||
| `UserPermissionController.php` | Wrong resource namespace; missing collection import | `Api\V1\UserPermissionResource` + `JsonApiResourceCollection` ||
| `*Resource.php` (10 files) | Namespace `App\Http\Resources\Api\v1` | `App\Http\Resources\Api\V1` ||
| `AttendanceLogPolicy.php` | Unused `Response` import; `create()` used `isOperator()` (managers included) | Dropped unused import; `create()` → `canManageDevices()` ||
| `AttendeeImportErrorPolicy.php` | Unused `Response` import | Removed ||
| `AttendeePolicy.php` | Unused `Response` import | Removed ||
| `BioTemplatePolicy.php` | Unused `Response`; `viewAny()` always true; `delete()` used `isOperator()` | `viewAny()` → `canReadEmployees()`; `delete()` → `canManageDevices()` ||
| `DevicePolicy.php` | Unused `Response`; `viewAny()` always true | `viewAny()` → `canManageDevices() \|\| canReadAttendance()` ||
| `PendingCommandPolicy.php` | Unused `Response`; `viewAny()` always true | `viewAny()` → `canManageCommands()` ||
| `PhotoPolicy.php` | Unused `Response`; `viewAny()` always true; `delete()` used `isOperator()` | `viewAny()` → `canReadEmployees()`; `delete()` → `canManageDevices()` ||
| `SitePolicy.php` | `viewAny()` always true | `viewAny()` → `canManageSites() \|\| canReadEmployees() \|\| canReadAttendance()` ||
| `AttendeeCreated.php` | `Attendee` type-hinted with no `use`; `broadcastOn()` but not `ShouldBroadcast` | Imported `Attendee`; `implements ShouldBroadcastNow` ||
| `AttendeeUpdated.php` | Broadcast methods without `ShouldBroadcast` | `implements ShouldBroadcastNow`; unused channel imports removed ||
| `AttendeeDeleted.php` | Unused broadcast imports (event is not broadcast) | Kept dispatch/serialize only ||
| `DeviceApproved.php` | `broadcastOn()` without `ShouldBroadcast` | `implements ShouldBroadcastNow` ||
| `DeviceBlocked.php` | `broadcastOn()` without `ShouldBroadcast` | `implements ShouldBroadcastNow` ||
| `CommandQueued.php` | `broadcastOn()` without `ShouldBroadcast` | `implements ShouldBroadcastNow` ||
| `DeviceOffline.php` | Public `Channel('devices')` leaked serial/IP; event name `offline` | Private channels (+ site); `device.offline`; payload aligned with other device events ||
