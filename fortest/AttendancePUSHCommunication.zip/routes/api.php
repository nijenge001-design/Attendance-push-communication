<?php

declare(strict_types=1);

use App\Http\Controllers\Api\v1\AttendanceLogController;
use App\Http\Controllers\Api\v1\AttendeeController;
use App\Http\Controllers\Api\v1\AttendeeImportErrorController;
use App\Http\Controllers\Api\v1\AuthController;
use App\Http\Controllers\Api\v1\BioTemplateController;
use App\Http\Controllers\Api\v1\DeviceController;
use App\Http\Controllers\Api\v1\PendingCommandController;
use App\Http\Controllers\Api\v1\PhotoController;
use App\Http\Controllers\Api\v1\SiteController;
use App\Http\Controllers\Api\v1\UserController;
use App\Http\Controllers\Api\v1\UserPermissionController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes (v1)
|--------------------------------------------------------------------------
|
| Prefixed with /api (bootstrap/app.php). Auth: Laravel Sanctum.
|
| Devices are bound by UUID or serial_number (Device::resolveRouteBinding).
|
*/

Route::prefix('v1')->group(function () {

    // ── Public ────────────────────────────────────────────────────────
    Route::post('login', [AuthController::class, 'login'])
        ->middleware('throttle:5,1');

    // ── Authenticated ─────────────────────────────────────────────────
    Route::middleware('auth:sanctum')->group(function () {

        // Auth
        Route::get('me', [AuthController::class, 'me']);
        Route::post('logout', [AuthController::class, 'logout']);
        Route::post('logout-all', [AuthController::class, 'logoutAll']);

        // Sites
        Route::apiResource('sites', SiteController::class);

        // Devices (index/show/destroy by serial or UUID; nested create/update under site)
        Route::get('devices', [DeviceController::class, 'index']);
        Route::post('sites/{site}/devices', [DeviceController::class, 'store']);
        Route::get('devices/{device}', [DeviceController::class, 'show']);
        Route::match(['put', 'patch'], 'sites/{site}/devices/{device}', [DeviceController::class, 'update']);
        Route::delete('devices/{device}', [DeviceController::class, 'destroy']);
        Route::post('devices/{device}/approve', [DeviceController::class, 'approve']);
        Route::post('devices/{device}/block', [DeviceController::class, 'block']);

        // Attendees
        Route::apiResource('attendees', AttendeeController::class);
        Route::post('attendees/{attendee}/grant-device-access', [AttendeeController::class, 'grantDeviceAccess']);
        Route::post('attendees/{attendee}/revoke-device-access', [AttendeeController::class, 'revokeDeviceAccess']);

        // Pending commands
        Route::get('pending-commands', [PendingCommandController::class, 'index']);
        Route::post('devices/{device}/commands', [PendingCommandController::class, 'store']);

        // Attendance logs
        Route::get('attendance-logs', [AttendanceLogController::class, 'index']);
        Route::get('attendance-logs/{attendanceLog}', [AttendanceLogController::class, 'show']);
        Route::post('devices/{device}/attendance-logs', [AttendanceLogController::class, 'store']);
        Route::delete('attendance-logs/{attendanceLog}', [AttendanceLogController::class, 'destroy']);

        // Bio templates
        Route::get('bio-templates', [BioTemplateController::class, 'index']);
        Route::get('bio-templates/{bioTemplate}', [BioTemplateController::class, 'show']);
        Route::delete('bio-templates/{bioTemplate}', [BioTemplateController::class, 'destroy']);

        // Photos
        Route::get('photos', [PhotoController::class, 'index']);
        Route::get('photos/{photo}', [PhotoController::class, 'show']);
        Route::delete('photos/{photo}', [PhotoController::class, 'destroy']);

        // Attendee import errors
        Route::get('attendee-import-errors', [AttendeeImportErrorController::class, 'index']);
        Route::get('attendee-import-errors/{attendeeImportError}', [AttendeeImportErrorController::class, 'show']);
        Route::post('attendee-import-errors/{attendeeImportError}/resolve', [AttendeeImportErrorController::class, 'resolve']);
        Route::post('attendee-import-errors/{attendeeImportError}/ignore', [AttendeeImportErrorController::class, 'ignore']);

        // Users
        Route::apiResource('users', UserController::class);

        // User permission overrides
        Route::get('users/{user}/permissions', [UserPermissionController::class, 'index']);
        Route::post('users/{user}/permissions', [UserPermissionController::class, 'store']);
        Route::match(['put', 'patch'], 'users/{user}/permissions/{userPermission}', [UserPermissionController::class, 'update']);
        Route::delete('users/{user}/permissions/{userPermission}', [UserPermissionController::class, 'destroy']);
        Route::get('users/{user}/permissions/effective', [UserPermissionController::class, 'effective']);
    });
});
