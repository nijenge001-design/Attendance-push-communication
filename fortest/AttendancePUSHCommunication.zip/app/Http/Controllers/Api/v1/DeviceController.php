<?php

namespace App\Http\Controllers\Api\v1;

use App\Events\DeviceApproved;
use App\Events\DeviceBlocked;
use App\Http\Controllers\Controller;
use App\Http\Resources\Api\v1\DeviceResource;
use App\Models\Device;
use App\Models\Site;
use Illuminate\Http\Request;
use Illuminate\Routing\Attributes\Controllers\Authorize;

class DeviceController extends Controller
{
    #[Authorize('viewAny', Device::class)]
    public function index(Request $request)
    {
        $query = Device::query()
            ->accessibleBy($request->user());

        $siteIds = $request->user()->accessibleSiteIds();
        if ($siteIds !== null) {
            $query->whereIn('site_id', $siteIds);
        }

        if ($status = $request->input('filter.status')) {
            $query->where('status', $status);
        }

        if ($request->boolean('filter.online')) {
            $query->online();
        }

        if ($request->boolean('filter.offline')) {
            $query->offline();
        }

        if ($siteId = $request->input('filter.site')) {
            $query->where('site_id', $siteId);
        }

        if ($search = $request->input('filter.search')) {
            $query->where(function ($q) use ($search) {
                $q->where('serial_number', 'like', "%{$search}%")
                    ->orWhere('device_name', 'like', "%{$search}%")
                    ->orWhere('ip', 'like', "%{$search}%");
            });
        }

        $devices = $query->latest('last_seen_at')->paginate($request->input('page.size', 15));

        return DeviceResource::collection($devices);
    }

    /**
     * Route: POST /sites/{site}/devices
     *
     * Array syntax: ['site', Device::class]
     *   - 'site'         → resolves the bound Site model as the first argument
     *   - Device::class  → tells Laravel the policy target class (needed because
     *                      the first element is a model, not a class)
     */

    #[Authorize('create', ['site', Device::class])]
    public function store(Request $request, Site $site): DeviceResource
    {
        $validated = $request->validate([
            'data.attributes.serialNumber' => 'required|string|unique:devices,serial_number',
            'data.attributes.deviceName' => 'nullable|string|max:255',
            'data.attributes.status' => 'sometimes|in:pending,approved,blocked',
        ]);

        $attrs = $validated['data']['attributes'];

        $device = Device::create([
            'serial_number' => $attrs['serialNumber'],
            'device_name' => $attrs['deviceName'] ?? null,
            'site_id' => $site->id,
            'status' => $attrs['status'] ?? Device::STATUS_PENDING,
        ]);

        return new DeviceResource($device);
    }

    /**
     * Route: GET /devices/{device}
     *
     * String syntax is sufficient — only the Device is needed.
     * 'device' resolves to the bound Device model.
     */

    #[Authorize('view', 'device')]
    public function show(Device $device): DeviceResource
    {
        return new DeviceResource($device);
    }

    /**
     * Route: PUT /sites/{site}/devices/{device}
     *
     * Array syntax: ['device', 'site']
     *   - First element is the route param whose model is passed first
     *   - Subsequent elements are additional args passed positionally
     *
     * NOTE: The policy must accept `Site` (not string) as its third arg.
     */

    #[Authorize('update', ['device', 'site'])]
    public function update(Request $request, Site $site, Device $device): DeviceResource
    {
        $validated = $request->validate([
            'data.attributes.deviceName' => 'sometimes|string|max:255',
            'data.attributes.status' => 'sometimes|in:pending,approved,blocked',
            'data.attributes.rejectionReason' => 'nullable|string',
        ]);

        $attrs = $validated['data']['attributes'] ?? [];

        $data = array_filter([
            'device_name' => $attrs['deviceName'] ?? null,
            'status' => $attrs['status'] ?? null,
            'rejection_reason' => $attrs['rejectionReason'] ?? null,
        ], fn($v) => $v !== null);

        if (isset($data['status']) && $data['status'] === Device::STATUS_APPROVED) {
            $data['approved_at'] = now();
            $data['rejection_reason'] = null;
        }

        $device->update($data);
        $device = $device->fresh();

        if (isset($data['status']) && $data['status'] === Device::STATUS_APPROVED) {
            event(new DeviceApproved($device));
        }

        return new DeviceResource($device);
    }

    #[Authorize('delete', 'device')]
    public function destroy(Device $device)
    {
        $device->delete();

        return response()->json(null, 204);
    }

    #[Authorize('approve', 'device')]
    public function approve(Device $device): DeviceResource
    {
        $device->approve();
        $device = $device->fresh();

        event(new DeviceApproved($device));

        return new DeviceResource($device);
    }

    #[Authorize('block', 'device')]
    public function block(Request $request, Device $device): DeviceResource
    {
        $reason = $request->input('data.attributes.rejectionReason');

        $device->block($reason);
        $device = $device->fresh();

        event(new DeviceBlocked($device, $reason));

        return new DeviceResource($device);
    }
}
