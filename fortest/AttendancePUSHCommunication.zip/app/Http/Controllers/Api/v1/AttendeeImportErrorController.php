<?php

namespace App\Http\Controllers\Api\v1;

use App\Http\Controllers\Controller;
use App\Http\Resources\Api\v1\AttendeeImportErrorResource;
use App\Models\AttendeeImportError;
use App\Models\Device;
use Illuminate\Http\Request;
use Illuminate\Routing\Attributes\Controllers\Authorize;

class AttendeeImportErrorController extends Controller
{
    #[Authorize('viewAny', AttendeeImportError::class)]
    public function index(Request $request)
    {
        $query = AttendeeImportError::query()
            ->accessibleBy($request->user());

        $siteIds = $request->user()->accessibleSiteIds();
        if ($siteIds !== null) {
            $serials = Device::whereIn('site_id', $siteIds)->pluck('serial_number');
            $query->whereIn('device_serial', $serials);
        }

        if ($status = $request->input('filter.status')) {
            $query->where('status', $status);
        } else {
            $query->pending();
        }

        if ($device = $request->input('filter.device')) {
            $query->where('device_serial', $device);
        }

        if ($pin = $request->input('filter.pin')) {
            $query->where('pin', $pin);
        }

        $errors = $query->latest()->paginate($request->input('page.size', 20));

        return AttendeeImportErrorResource::collection($errors);
    }

    #[Authorize('view', 'attendeeImportError')]
    public function show(AttendeeImportError $attendeeImportError): AttendeeImportErrorResource
    {
        return new AttendeeImportErrorResource($attendeeImportError);
    }

    #[Authorize('resolve', 'attendeeImportError')]
    public function resolve(Request $request, AttendeeImportError $attendeeImportError): AttendeeImportErrorResource
    {
        $note = $request->input('data.attributes.adminNote');
        $attendeeImportError->markResolved($note);

        return new AttendeeImportErrorResource($attendeeImportError->fresh());
    }

    #[Authorize('ignore', 'attendeeImportError')]
    public function ignore(Request $request, AttendeeImportError $attendeeImportError): AttendeeImportErrorResource
    {
        $note = $request->input('data.attributes.adminNote');
        $attendeeImportError->markIgnored($note);

        return new AttendeeImportErrorResource($attendeeImportError->fresh());
    }
}
