<?php

namespace App\Http\Controllers\Api\v1;

use App\Http\Controllers\Controller;
use App\Http\Resources\Api\v1\AttendanceLogResource;
use App\Models\AttendanceLog;
use App\Models\Device;
use Illuminate\Http\Request;
use Illuminate\Routing\Attributes\Controllers\Authorize;

class AttendanceLogController extends Controller
{
    #[Authorize('viewAny', AttendanceLog::class)]
    public function index(Request $request)
    {
        $query = AttendanceLog::query()
            ->accessibleBy($request->user());

        $siteIds = $request->user()->accessibleSiteIds();
        if ($siteIds !== null) {
            $serials = Device::whereIn('site_id', $siteIds)->pluck('serial_number');
            $query->whereIn('device_serial', $serials);
        }

        if ($pin = $request->input('filter.pin')) {
            $query->forPin($pin);
        }

        if ($device = $request->input('filter.device')) {
            $query->forDevice($device);
        }

        if ($request->boolean('filter.today')) {
            $query->today();
        }

        if ($start = $request->input('filter.start')) {
            $end = $request->input('filter.end', now());
            $query->betweenDates($start, $end);
        }

        if ($request->boolean('filter.withMask')) {
            $query->withMask();
        }

        if ($request->boolean('filter.hasTemperature')) {
            $query->hasTemperature();
        }

        $logs = $query->latest('timestamp')->paginate($request->input('page.size', 50));

        return AttendanceLogResource::collection($logs);
    }

    #[Authorize('view', 'attendanceLog')]
    public function show(AttendanceLog $attendanceLog): AttendanceLogResource
    {
        return new AttendanceLogResource($attendanceLog);
    }

    /**
     * Route: POST /devices/{device}/attendance-logs
     *
     * Array syntax: ['device', AttendanceLog::class]
     *   - 'device'               → route-bound Device passed as first arg
     *   - AttendanceLog::class   → policy target class
     *
     * The `deviceSerial` in the request body must match the route-bound device.
     */
    #[Authorize('create', ['device', AttendanceLog::class])]
    public function store(Request $request, Device $device): AttendanceLogResource
    {
        $validated = $request->validate([
            'data.attributes.pin' => 'required|string',
            'data.attributes.timestamp' => 'required|date',
            'data.attributes.status' => 'required|integer',
            'data.attributes.verifyMode' => 'required|integer',
            'data.attributes.workcode' => 'nullable|string',
            'data.attributes.type' => 'integer',
            'data.attributes.maskFlag' => 'nullable|integer',
            'data.attributes.temperature' => 'nullable|numeric',
            'data.attributes.convTemperature' => 'nullable|numeric',
        ]);

        $attrs = $validated['data']['attributes'];


        $log = AttendanceLog::create([
            'pin' => $attrs['pin'],
            'device_serial' => $device->serial_number, // trust route binding over body
            'timestamp' => $attrs['timestamp'],
            'status' => $attrs['status'],
            'verify_mode' => $attrs['verifyMode'],
            'workcode' => $attrs['workcode'] ?? null,
            'type' => $attrs['type'] ?? 0,
            'mask_flag' => $attrs['maskFlag'] ?? null,
            'temperature' => $attrs['temperature'] ?? null,
            'conv_temperature' => $attrs['convTemperature'] ?? null,
        ]);

        return new AttendanceLogResource($log);
    }

    #[Authorize('delete', 'attendanceLog')]
    public function destroy(AttendanceLog $attendanceLog)
    {
        $attendanceLog->delete();

        return response()->json(null, 204);
    }
}
