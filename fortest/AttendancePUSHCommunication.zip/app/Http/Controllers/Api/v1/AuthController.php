<?php

namespace App\Http\Controllers\Api\v1;

use App\Http\Controllers\Controller;
use App\Http\Resources\Api\v1\UserResource;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;

class AuthController extends Controller
{
    /**
     * Login with username, email, or phone_number.
     */
    public function login(Request $request)
    {
        $validated = $request->validate([
            'login' => 'required|string',
            'password' => 'required|string',
            'device_name' => 'nullable|string|max:255',
        ]);

        $login = $validated['login'];

        $user = User::query()
            ->where('username', $login)
            ->orWhere('email', $login)
            ->orWhere('phone_number', $login)
            ->first();

        if (!$user || !Hash::check($validated['password'], $user->password)) {
            throw ValidationException::withMessages([
                'login' => ['The provided credentials are incorrect.'],
            ]);
        }

        $token = $user->createToken($validated['device_name'] ?? 'api', ['*']);

        return response()->json([
            'data' => [
                'type' => 'tokens',
                'attributes' => [
                    'token' => $token->plainTextToken,
                    'tokenType' => 'Bearer',
                    'abilities' => $token->accessToken->abilities ?? ['*'],
                ],
            ],
            'included' => [
                (new UserResource($user))->resolve(),
            ],
        ])->header('Content-Type', 'application/vnd.api+json');
    }

    public function me(Request $request): UserResource
    {
        return new UserResource($request->user()->load('sites'));
    }

    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();

        return response()->json(null, 204);
    }

    public function logoutAll(Request $request)
    {
        $request->user()->tokens()->delete();

        return response()->json(null, 204);
    }
}
