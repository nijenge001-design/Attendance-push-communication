<?php

namespace App\Http\Controllers\Api\v1;

use App\Events\AttendeeAccessGranted;
use App\Events\AttendeeAccessRevoked;
use App\Events\AttendeeCreated;
use App\Events\AttendeeDeleted;
use App\Events\AttendeeUpdated;
use App\Http\Controllers\Controller;
use App\Http\Resources\Api\v1\AttendeeResource;
use App\Models\Attendee;
use Illuminate\Http\Request;
use Illuminate\Routing\Attributes\Controllers\Authorize;

class AttendeeController extends Controller
{
    #[Authorize('viewAny', Attendee::class)]
    public function index(Request $request)
    {
        $query = Attendee::query()
            ->accessibleBy($request->user());

        $siteIds = $request->user()->accessibleSiteIds();
        if ($siteIds !== null) {
            $query->where(function ($q) use ($siteIds) {
                $q->whereHas('sites', fn($s) => $s->whereIn('sites.id', $siteIds))
                    ->orWhereHas('devices', fn($d) => $d->whereIn('site_id', $siteIds));
            });
        }

        if ($pin = $request->input('filter.pin')) {
            $query->where('pin', $pin);
        }

        if ($deviceSerial = $request->input('filter.device')) {
            $query->onDevice($deviceSerial);
        }

        if ($search = $request->input('filter.search')) {
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                    ->orWhere('pin', 'like', "%{$search}%")
                    ->orWhere('card_number', 'like', "%{$search}%");
            });
        }

        $attendees = $query->latest()->paginate($request->input('page.size', 15));

        return AttendeeResource::collection($attendees);
    }

    #[Authorize('create', Attendee::class)]
    public function store(Request $request): AttendeeResource
    {
        $validated = $request->validate([
            'data.attributes.pin' => 'required|string|unique:attendees,pin',
            'data.attributes.name' => 'nullable|string|max:255',
            'data.attributes.privilege' => 'integer',
            'data.attributes.password' => 'nullable|string',
            'data.attributes.cardNumber' => 'nullable|string|unique:attendees,card_number',
            'data.attributes.viceCard' => 'nullable|string',
            'data.attributes.groupId' => 'integer',
            'data.attributes.timezone' => 'nullable|string',
            'data.attributes.verificationMode' => 'integer',
            'data.attributes.siteIds' => 'nullable|array',
            'data.attributes.siteIds.*' => 'uuid|exists:sites,id',
            'data.attributes.deviceSerials' => 'nullable|array',
            'data.attributes.deviceSerials.*' => 'string|exists:devices,serial_number',
        ]);

        $attrs = $validated['data']['attributes'];

        $attendee = Attendee::create([
            'pin' => $attrs['pin'],
            'name' => $attrs['name'] ?? null,
            'privilege' => $attrs['privilege'] ?? 0,
            'password' => $attrs['password'] ?? null,
            'card_number' => $attrs['cardNumber'] ?? null,
            'vice_card' => $attrs['viceCard'] ?? null,
            'group_id' => $attrs['groupId'] ?? 1,
            'timezone' => $attrs['timezone'] ?? null,
            'verification_mode' => $attrs['verificationMode'] ?? -1,
        ]);

        if (!empty($attrs['siteIds'])) {
            foreach ($attrs['siteIds'] as $siteId) {
                if ($request->user()->hasAccessToSite($siteId)) {
                    $attendee->sites()->syncWithoutDetaching([
                        $siteId => ['is_active' => true, 'granted_at' => now()],
                    ]);
                }
            }
        }

        $deviceSerials = $attrs['deviceSerials'] ?? [];
        foreach ($deviceSerials as $serial) {
            $attendee->grantAccessToDevice($serial);
        }

        event(new AttendeeCreated($attendee, $deviceSerials));

        return new AttendeeResource($attendee->load(['sites', 'devices']));
    }

    #[Authorize('view', 'attendee')]
    public function show(Attendee $attendee): AttendeeResource
    {
        return new AttendeeResource($attendee);
    }

    #[Authorize('update', 'attendee')]
    public function update(Request $request, Attendee $attendee): AttendeeResource
    {
        $validated = $request->validate([
            'data.attributes.name' => 'sometimes|string|max:255',
            'data.attributes.privilege' => 'integer',
            'data.attributes.password' => 'nullable|string',
            'data.attributes.cardNumber' => 'nullable|string|unique:attendees,card_number,' . $attendee->id,
            'data.attributes.viceCard' => 'nullable|string',
            'data.attributes.groupId' => 'integer',
            'data.attributes.timezone' => 'nullable|string',
            'data.attributes.verificationMode' => 'integer',
        ]);

        $attrs = $validated['data']['attributes'] ?? [];

        $attendee->update(array_filter([
            'name' => $attrs['name'] ?? null,
            'privilege' => $attrs['privilege'] ?? null,
            'password' => $attrs['password'] ?? null,
            'card_number' => $attrs['cardNumber'] ?? null,
            'vice_card' => $attrs['viceCard'] ?? null,
            'group_id' => $attrs['groupId'] ?? null,
            'timezone' => $attrs['timezone'] ?? null,
            'verification_mode' => $attrs['verificationMode'] ?? null,
        ], fn($v) => $v !== null));

        $attendee = $attendee->fresh();
        event(new AttendeeUpdated($attendee));

        return new AttendeeResource($attendee);
    }

    #[Authorize('delete', 'attendee')]
    public function destroy(Attendee $attendee)
    {
        $pin = $attendee->pin;
        $serials = $attendee->devices()->pluck('serial_number')->all();

        $attendee->delete();

        event(new AttendeeDeleted($pin, $serials));

        return response()->json(null, 204);
    }

    #[Authorize('manageAccess', 'attendee')]
    public function grantDeviceAccess(Request $request, Attendee $attendee)
    {
        $validated = $request->validate([
            'data.attributes.deviceSerial' => 'required|string|exists:devices,serial_number',
            'data.attributes.privilege' => 'nullable|integer',
            'data.attributes.groupId' => 'nullable|integer',
            'data.attributes.timezone' => 'nullable|string',
        ]);

        $attrs = $validated['data']['attributes'];

        $attendee->grantAccessToDevice(
            $attrs['deviceSerial'],
            array_filter([
                'privilege' => $attrs['privilege'] ?? null,
                'group_id' => $attrs['groupId'] ?? null,
                'timezone' => $attrs['timezone'] ?? null,
            ])
        );

        event(new AttendeeAccessGranted($attendee, $attrs['deviceSerial']));

        return new AttendeeResource($attendee->load('devices'));
    }

    #[Authorize('manageAccess', 'attendee')]
    public function revokeDeviceAccess(Request $request, Attendee $attendee)
    {
        $validated = $request->validate([
            'data.attributes.deviceSerial' => 'required|string|exists:devices,serial_number',
        ]);

        $serial = $validated['data']['attributes']['deviceSerial'];
        $attendee->revokeAccessFromDevice($serial);

        event(new AttendeeAccessRevoked($attendee, $serial));

        return new AttendeeResource($attendee->load('devices'));
    }
}
