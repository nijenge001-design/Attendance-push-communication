<?php

namespace App\Listeners;

use App\Events\AttendeeCreated;
use App\Jobs\SyncAttendeeToDevices;

/** Push new attendee USERINFO to the listed devices. */
class SyncAttendeeOnCreated
{
    public function handle(AttendeeCreated $event): void
    {
        if ($event->deviceSerials === []) {
            return;
        }

        SyncAttendeeToDevices::dispatch(
            $event->attendee->pin,
            $event->deviceSerials,
        );
    }
}
