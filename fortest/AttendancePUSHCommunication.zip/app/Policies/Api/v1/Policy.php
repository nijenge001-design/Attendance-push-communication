<?php

namespace App\Policies\Api\v1;

use App\Models\Device;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;
use Illuminate\Auth\Access\Response;

/**
 * Base policy for all API (v1) policies.
 *
 * Design principles
 * -----------------
 * 1. Admin bypass lives here (single source of truth).
 *    Child policies should almost never re-implement admin checks.
 *
 * 2. Cross-tenant reads use denyAsNotFound() so we do not leak
 *    the existence of resources the user cannot access.
 *
 * 3. Permission checks use the User helpers (canManageDevices(), etc.)
 *    which already combine role defaults + per-user overrides.
 *
 * 4. Device-scoped resources resolve the Device either from the model
 *    itself, a loaded relation, or a device_serial column.
 */
abstract class Policy
{
    use HandlesAuthorization;

    /**
     * Global admin bypass.
     *
     * Returns true for admins (allow everything) or null so the
     * specific policy method is evaluated for non-admins.
     *
     * Child policies may override this for special self-protection
     * cases (see UserPolicy).
     */
    public function before(User $user, string $ability, mixed ...$arguments): bool|null
    {
        // Admins skip all subsequent checks in child policies.
        // Returning null lets the specific ability method run for everyone else.
        return $user->isAdmin() ? true : null;
    }

    /**
     * Convenience wrapper for Response::allow().
     */
    protected function allow(): Response
    {
        return Response::allow();
    }

    /**
     * Allow when $condition is true, otherwise deny with the given message.
     */
    protected function allowIf(bool $condition, string $message): Response
    {
        return $condition
            ? Response::allow()
            : Response::deny($message);
    }

    /**
     * Authorize a device-scoped resource.
     *
     * @param User $user
     * @param object|null $model The model being authorized (Device itself or a model that belongs to a device)
     * @param bool $hide When true (default) lack of access returns 404 (denyAsNotFound).
     *                              When false returns a regular 403 deny.
     * @return Response
     */
    protected function authorizeDevice(User $user, object|null $model, bool $hide = true): Response
    {
        // Resolve the underlying Device from the model (or its serial).
        $device = $this->resolveDevice($model);

        // No resolvable device → treat as missing (or explicit deny when hide=false).
        if (!$device instanceof Device) {
            return $hide
                ? Response::denyAsNotFound()   // 404 – do not leak existence
                : Response::deny('Device not found.');
        }

        // User must have access to the device's site.
        if ($user->hasAccessToDevice($device)) {
            return Response::allow();
        }

        // Cross-tenant: hide existence on reads, explicit deny on writes.
        return $hide
            ? Response::denyAsNotFound()
            : Response::deny('You do not have access to this device.');
    }

    /**
     * Authorize access to a site.
     *
     * @param User $user
     * @param string|null $siteId
     * @param bool $hide When true (default) lack of access returns 404.
     * @return Response
     */
    protected function authorizeSite(User $user, ?string $siteId, bool $hide = true): Response
    {
        // No site context supplied → nothing to restrict.
        if ($siteId === null || $siteId === '') {
            return Response::allow();
        }

        // User is assigned to this site (or is admin).
        if ($user->hasAccessToSite($siteId)) {
            return Response::allow();
        }

        // Cross-tenant protection.
        return $hide
            ? Response::denyAsNotFound()
            : Response::deny('You do not have access to this site.');
    }

    /**
     * Resolve a Device instance from a model that may or may not have the relation loaded.
     *
     * Resolution order:
     *  1. The model is itself a Device
     *  2. The model has a loaded `device` relation
     *  3. The model has a `device_serial` attribute → lookup
     */
    protected function resolveDevice(object|null $model): ?Device
    {
        if ($model === null) {
            return null;
        }

        // Direct Device instance (e.g. authorizeDevice($user, $device)).
        if ($model instanceof Device) {
            return $model;
        }

        // Prefer already-loaded relation to avoid an extra query.
        if (isset($model->device) && $model->device instanceof Device) {
            return $model->device;
        }

        // Fallback: look up by serial number (common on logs, commands, templates…).
        if (isset($model->device_serial) && is_string($model->device_serial)) {
            return Device::query()
                ->where('serial_number', $model->device_serial)
                ->first();
        }

        return null;
    }
}
