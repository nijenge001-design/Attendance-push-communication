<?php

namespace App\Policies\Api\v1;

use App\Models\Photo;
use App\Models\User;
use Illuminate\Auth\Access\Response;

/**
 * Authorization for Photo resources (user photos captured by devices).
 *
 * Photos are device-scoped. Access follows the device’s site.
 *
 * Permissions used:
 *  - ReadEmployees or ReadAttendance → list / view
 *  - ManageEmployees or ManageDevices → delete
 */
class PhotoPolicy extends Policy
{
    /**
     * List photos.
     *
     * Controller should further filter by accessible devices/sites.
     */
    public function viewAny(User $user): Response
    {
        // Either employee or attendance readers may list photos.
        return $this->allowIf(
            $user->canReadEmployees() || $user->canReadAttendance(),
            'You are not allowed to list photos.',
        );
    }

    /**
     * View a single photo.
     */
    public function view(User $user, Photo $photo): Response
    {
        // Same permission gate as viewAny.
        if (! $user->canReadEmployees() && ! $user->canReadAttendance()) {
            return Response::deny('You are not allowed to view photos.');
        }

        // Photo belongs to a device → enforce site access.
        return $this->authorizeDevice($user, $photo);
    }

    /**
     * Delete a photo.
     */
    public function delete(User $user, Photo $photo): Response
    {
        // Only users who can manage employees or devices may delete photos.
        if (! $user->canManageEmployees() && ! $user->canManageDevices()) {
            return Response::deny('You are not allowed to delete photos.');
        }

        return $this->authorizeDevice($user, $photo);
    }
}
