<?php

namespace App\Policies\Api\v1;

use App\Models\Device;
use App\Models\Site;
use App\Models\User;
use Illuminate\Auth\Access\Response;

/**
 * Authorization for Device resources.
 *
 * Multi-tenancy: Devices belong to a Site. Access is granted when the
 * user has access to that site (or is an admin).
 *
 * Permissions used:
 *  - ManageDevices  → create / update
 *  - ApproveDevices → approve / block
 *  - ReadAttendance → also allowed to list & view (read-only consumers)
 *
 * Destructive delete is reserved for administrators only.
 */
class DevicePolicy extends Policy
{
    /**
     * List devices.
     *
     * The actual result set is further filtered by accessible sites
     * in the controller/query layer. Here we only gate the ability
     * to hit the endpoint at all.
     */
    public function viewAny(User $user): Response
    {
        // Any of these permissions is enough to open the list endpoint.
        // The query itself will still be scoped to the user's sites.
        return $this->allowIf(
            $user->canManageDevices() || $user->canApproveDevices() || $user->canReadAttendance(),
            'You are not allowed to list devices.',
        );
    }

    /**
     * View a single device.
     *
     * Re-checks a relevant permission so users with zero device-related
     * permissions cannot reach a device even if they know its ID.
     * Then enforces site-level access via authorizeDevice().
     */
    public function view(User $user, Device $device): Response
    {
        // First gate: user must hold at least one device-related permission.
        if (! $user->canManageDevices() && ! $user->canApproveDevices() && ! $user->canReadAttendance()) {
            return Response::deny('You are not allowed to view devices.');
        }

        // Second gate: user must have access to the device's site
        // (returns 404 for cross-tenant requests).
        return $this->authorizeDevice($user, $device);
    }

    /**
     * Create a device under a site.
     *
     * Called via #[Authorize('create', ['site', Device::class])].
     * The bound Site model is passed as the second argument.
     */
    public function create(User $user, ?Site $site = null): Response
    {
        // Only users who can manage devices may create them.
        if (! $user->canManageDevices()) {
            return Response::deny('You are not allowed to create devices.');
        }

        // Ensure the user can access the target site.
        // hide=false → 403 (client explicitly chose the site, so we can say "no access").
        return $this->authorizeSite($user, $site?->id, hide: false);
    }

    /**
     * Update a device (optionally moving it to another site).
     *
     * Called via #[Authorize('update', ['device', 'site'])].
     * Both the Device and the (optional) target Site are passed.
     */
    public function update(User $user, Device $device, ?Site $site = null): Response
    {
        if (! $user->canManageDevices()) {
            return Response::deny('You are not allowed to update devices.');
        }

        // Must already have access to the current device.
        $deviceAccess = $this->authorizeDevice($user, $device);
        if ($deviceAccess->denied()) {
            return $deviceAccess; // 404 if cross-tenant
        }

        // If a target site is supplied (e.g. moving the device),
        // the user must also have access to that site.
        return $this->authorizeSite($user, $site?->id, hide: false);
    }

    /**
     * Delete a device.
     *
     * Intentionally restricted to administrators only.
     * Non-admins always receive a deny (admins are handled by before()).
     */
    public function delete(User $user, Device $device): Response
    {
        // Hard deny for everyone who reaches this method.
        // Admins never reach here because before() already returned true.
        return Response::deny('Only administrators can delete devices.');
    }

    /**
     * Approve a pending device.
     */
    public function approve(User $user, Device $device): Response
    {
        if (! $user->canApproveDevices()) {
            return Response::deny('You are not allowed to approve devices.');
        }

        // Must have access to the device's site.
        return $this->authorizeDevice($user, $device);
    }

    /**
     * Block a device.
     */
    public function block(User $user, Device $device): Response
    {
        if (! $user->canApproveDevices()) {
            return Response::deny('You are not allowed to block devices.');
        }

        return $this->authorizeDevice($user, $device);
    }
}
