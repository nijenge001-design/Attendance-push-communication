<?php

namespace App\Policies\Api\v1;

use App\Models\AttendanceLog;
use App\Models\Device;
use App\Models\User;
use Illuminate\Auth\Access\Response;

/**
 * Authorization for AttendanceLog resources.
 *
 * Logs are device-scoped (they carry a device_serial).
 * Access follows the device’s site.
 *
 * Permissions used:
 *  - ReadAttendance   → list / view
 *  - ManageEmployees or ManageDevices → manual creation
 *
 * Delete is reserved for administrators only.
 */
class AttendanceLogPolicy extends Policy
{
    /**
     * List attendance logs.
     *
     * Controller further restricts the query to devices belonging
     * to sites the user can access.
     */
    public function viewAny(User $user): Response
    {
        return $this->allowIf(
            $user->canReadAttendance(),
            'You are not allowed to view attendance logs.',
        );
    }

    /**
     * View a single attendance log.
     */
    public function view(User $user, AttendanceLog $attendanceLog): Response
    {
        // Permission gate.
        if (! $user->canReadAttendance()) {
            return Response::deny('You are not allowed to view attendance logs.');
        }

        // Log belongs to a device → enforce site access (404 if cross-tenant).
        return $this->authorizeDevice($user, $attendanceLog);
    }

    /**
     * Manually create an attendance log for a device.
     *
     * Called via #[Authorize('create', ['device', AttendanceLog::class])].
     * Normal punches arrive from devices via the PUSH protocol and
     * do not go through this policy.
     */
    public function create(User $user, ?Device $device = null): Response
    {
        // Manual creation is restricted to users who can manage
        // employees or devices (not pure viewers).
        if (! $user->canManageEmployees() && ! $user->canManageDevices()) {
            return Response::deny('You are not allowed to create attendance logs.');
        }

        // A concrete target device is required; hide=false → 403.
        return $device
            ? $this->authorizeDevice($user, $device, hide: false)
            : Response::deny('A target device is required.');
    }

    /**
     * Delete an attendance log.
     *
     * Intentionally restricted to administrators only.
     */
    public function delete(User $user, AttendanceLog $attendanceLog): Response
    {
        // Hard deny for non-admins. Admins never reach this line.
        return Response::deny('Only administrators can delete attendance logs.');
    }
}
