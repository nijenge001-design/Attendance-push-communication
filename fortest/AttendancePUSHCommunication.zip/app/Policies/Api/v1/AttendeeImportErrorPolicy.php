<?php

namespace App\Policies\Api\v1;

use App\Models\AttendeeImportError;
use App\Models\User;
use Illuminate\Auth\Access\Response;

/**
 * Authorization for AttendeeImportError resources.
 *
 * Import errors are produced when a device pushes user data that
 * cannot be cleanly imported. They are device-scoped.
 *
 * Permissions used:
 *  - ResolveImportErrors → list / view / resolve / ignore
 */
class AttendeeImportErrorPolicy extends Policy
{
    /**
     * List import errors.
     *
     * Controller further restricts the query to devices belonging
     * to sites the user can access.
     */
    public function viewAny(User $user): Response
    {
        return $this->allowIf(
            $user->canResolveImportErrors(),
            'You are not allowed to view attendee import errors.',
        );
    }

    /**
     * View a single import error.
     */
    public function view(User $user, AttendeeImportError $attendeeImportError): Response
    {
        // Permission gate first.
        if (! $user->canResolveImportErrors()) {
            return Response::deny('You are not allowed to view attendee import errors.');
        }

        // Error is tied to a device → enforce site access (404 if cross-tenant).
        return $this->authorizeDevice($user, $attendeeImportError);
    }

    /**
     * Mark an import error as resolved (and optionally create/update the attendee).
     *
     * Re-uses the same rules as view – if you can see it, you can resolve it.
     */
    public function resolve(User $user, AttendeeImportError $attendeeImportError): Response
    {
        return $this->view($user, $attendeeImportError);
    }

    /**
     * Ignore / dismiss an import error without taking action.
     *
     * Same rules as resolve.
     */
    public function ignore(User $user, AttendeeImportError $attendeeImportError): Response
    {
        return $this->view($user, $attendeeImportError);
    }
}
