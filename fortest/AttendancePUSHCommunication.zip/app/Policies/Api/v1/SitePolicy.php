<?php

namespace App\Policies\Api\v1;

use App\Models\Site;
use App\Models\User;
use Illuminate\Auth\Access\Response;

/**
 * Authorization for Site resources.
 *
 * Sites are the primary multi-tenant boundary.
 * Most other resources (devices, attendees, logs, …) inherit
 * access control from the sites a user is assigned to.
 *
 * Permissions used:
 *  - ManageSites → create / update
 *
 * Delete is reserved for administrators only.
 * viewAny is open (the controller filters to accessible sites).
 */
class SitePolicy extends Policy
{
    /**
     * List sites.
     *
     * Allowed for any authenticated user. The controller applies
     * the accessibleBy scope so users only see their own sites.
     */
    public function viewAny(User $user): Response
    {
        // No permission check here – every authenticated user may list
        // sites. The query scope ensures they only receive their own.
        return $this->allow();
    }

    /**
     * View a single site.
     *
     * Uses authorizeSite() which returns 404 when the user
     * does not have access (prevents existence leakage).
     */
    public function view(User $user, Site $site): Response
    {
        // 404 if the user is not assigned to this site.
        return $this->authorizeSite($user, $site->id);
    }

    /**
     * Create a new site.
     *
     * The creating user (if not admin) is automatically assigned
     * to the new site inside the controller.
     */
    public function create(User $user): Response
    {
        return $this->allowIf(
            $user->canManageSites(),
            'You are not allowed to create sites.',
        );
    }

    /**
     * Update an existing site.
     */
    public function update(User $user, Site $site): Response
    {
        if (! $user->canManageSites()) {
            return Response::deny('You are not allowed to update sites.');
        }

        // Must already have access to the site being updated.
        return $this->authorizeSite($user, $site->id);
    }

    /**
     * Delete a site.
     *
     * Intentionally restricted to administrators only.
     */
    public function delete(User $user, Site $site): Response
    {
        // Hard deny for non-admins. Admins are short-circuited by before().
        return Response::deny('Only administrators can delete sites.');
    }
}
