<?php

namespace App\Policies\Api\v1;

use App\Models\Attendee;
use App\Models\User;
use Illuminate\Auth\Access\Response;

/**
 * Authorization for Attendee (employee) resources.
 *
 * Multi-tenancy model
 * -------------------
 * Attendees can be linked to Sites directly and/or to Devices.
 * A user may see/manage an attendee when they share at least one
 * site (via the attendee’s sites or via devices that belong to
 * sites the user can access).
 *
 * Permissions used:
 *  - ReadEmployees   → list / view
 *  - ManageEmployees → create / update
 *  - DeleteEmployees → delete
 *  - ManageDevices   → grant / revoke device access
 */
class AttendeePolicy extends Policy
{
    /**
     * List attendees.
     *
     * Controller further filters by accessible sites.
     */
    public function viewAny(User $user): Response
    {
        return $this->allowIf(
            $user->canReadEmployees(),
            'You are not allowed to view attendees.',
        );
    }

    /**
     * View a single attendee.
     *
     * Requires ReadEmployees + shared site/device relationship.
     */
    public function view(User $user, Attendee $attendee): Response
    {
        // Permission gate first.
        if (! $user->canReadEmployees()) {
            return Response::deny('You are not allowed to view attendees.');
        }

        // Then multi-tenant check (404 if no shared site).
        return $this->sharesSiteWith($user, $attendee);
    }

    /**
     * Create a new attendee.
     *
     * Site/device attachment is validated inside the controller
     * (only sites the user can access are accepted).
     */
    public function create(User $user): Response
    {
        return $this->allowIf(
            $user->canManageEmployees(),
            'You are not allowed to create attendees.',
        );
    }

    /**
     * Update an existing attendee.
     */
    public function update(User $user, Attendee $attendee): Response
    {
        if (! $user->canManageEmployees()) {
            return Response::deny('You are not allowed to update attendees.');
        }

        // Must share a site with the attendee.
        return $this->sharesSiteWith($user, $attendee);
    }

    /**
     * Soft-delete an attendee.
     */
    public function delete(User $user, Attendee $attendee): Response
    {
        // Dedicated delete permission (not the same as manage).
        if (! $user->canDeleteEmployees()) {
            return Response::deny('You are not allowed to delete attendees.');
        }

        return $this->sharesSiteWith($user, $attendee);
    }

    /**
     * Grant or revoke device access for an attendee.
     *
     * Uses ManageDevices because this action ultimately queues
     * device commands.
     */
    public function manageAccess(User $user, Attendee $attendee): Response
    {
        // Pushing USERINFO / DELETE to a device is a device-management action.
        if (! $user->canManageDevices()) {
            return Response::deny('You are not allowed to manage attendee device access.');
        }

        return $this->sharesSiteWith($user, $attendee);
    }

    /**
     * Determine whether the user shares any site with the attendee.
     *
     * Checks both:
     *  - Direct attendee ↔ site pivot
     *  - Devices the attendee is linked to (via their site)
     *
     * Returns denyAsNotFound() on failure to avoid leaking existence.
     */
    protected function sharesSiteWith(User $user, Attendee $attendee): Response
    {
        $userSiteIds = $user->accessibleSiteIds();

        // Admin → accessibleSiteIds() returns null → unrestricted access.
        if ($userSiteIds === null) {
            return $this->allow();
        }

        // User has no sites assigned at all → nothing is visible.
        if ($userSiteIds === []) {
            return Response::denyAsNotFound();
        }

        // Attendee is reachable if they share a site directly
        // OR if they are linked to a device that belongs to one of the user's sites.
        $shares = $attendee->sites()->whereIn('sites.id', $userSiteIds)->exists()
            || $attendee->devices()->whereIn('site_id', $userSiteIds)->exists();

        return $shares
            ? $this->allow()
            : Response::denyAsNotFound(); // 404 – do not reveal the attendee exists
    }
}
