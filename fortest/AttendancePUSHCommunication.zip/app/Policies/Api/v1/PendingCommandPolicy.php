<?php

namespace App\Policies\Api\v1;

use App\Models\Device;
use App\Models\PendingCommand;
use App\Models\User;
use Illuminate\Auth\Access\Response;

/**
 * Authorization for PendingCommand resources (device command queue).
 *
 * Commands are device-scoped. Listing is filtered by the sites the
 * user can access in the controller; here we gate the ability itself.
 *
 * Permissions used:
 *  - ManageCommands → create / update / enable / disable / delete
 *  - ManageDevices  → also allowed to list & view (operators who manage devices)
 */
class PendingCommandPolicy extends Policy
{
    /**
     * List pending commands.
     *
     * Controller further restricts the query to devices belonging to
     * sites the user can access.
     */
    public function viewAny(User $user): Response
    {
        // ManageCommands is the primary permission; ManageDevices is a
        // convenience for operators who already manage the devices themselves.
        return $this->allowIf(
            $user->canManageCommands() || $user->canManageDevices(),
            'You are not allowed to list device commands.',
        );
    }

    /**
     * View a single pending command.
     */
    public function view(User $user, PendingCommand $pendingCommand): Response
    {
        // Same permission gate as viewAny.
        if (! $user->canManageCommands() && ! $user->canManageDevices()) {
            return Response::deny('You are not allowed to view device commands.');
        }

        // Then enforce that the command belongs to a device the user can access.
        return $this->authorizeDevice($user, $pendingCommand);
    }

    /**
     * Queue a new command for a device.
     *
     * Called via #[Authorize('create', ['device', PendingCommand::class])].
     * The bound Device is passed as the second argument.
     */
    public function create(User $user, ?Device $device = null): Response
    {
        // Only the dedicated ManageCommands permission may enqueue work.
        if (! $user->canManageCommands()) {
            return Response::deny('You are not allowed to queue device commands.');
        }

        // A concrete target device is required; hide=false → 403 (client chose it).
        return $device
            ? $this->authorizeDevice($user, $device, hide: false)
            : Response::deny('A target device is required.');
    }

    /**
     * Update / cancel / reschedule a command.
     */
    public function update(User $user, PendingCommand $pendingCommand): Response
    {
        if (! $user->canManageCommands()) {
            return Response::deny('You are not allowed to update device commands.');
        }

        // Command must belong to a device the user can access.
        return $this->authorizeDevice($user, $pendingCommand);
    }

    /**
     * Delete a pending command (same rules as update).
     */
    public function delete(User $user, PendingCommand $pendingCommand): Response
    {
        // Re-use update logic so the rules stay in one place.
        return $this->update($user, $pendingCommand);
    }

    /**
     * Enable a previously disabled command.
     */
    public function enable(User $user, PendingCommand $pendingCommand): Response
    {
        return $this->update($user, $pendingCommand);
    }

    /**
     * Disable a command so it will not be sent.
     */
    public function disable(User $user, PendingCommand $pendingCommand): Response
    {
        return $this->update($user, $pendingCommand);
    }
}
