<?php

namespace App\Policies\Api\v1;

use App\Enums\UserRole;
use App\Models\User;
use Illuminate\Auth\Access\Response;

/**
 * Authorization for User resources.
 *
 * Special rules
 * -------------
 * - Admins can do almost everything, but they cannot lock themselves
 *   out (delete their own account, rewrite their own site assignments
 *   or permission overrides). This is enforced in before().
 *
 * - Only admins may create other admins or assign the admin role.
 *
 * Permissions used:
 *  - ManageUsers → list / create / update / delete / manage sites & permissions
 *
 * Users may always view and update their own profile (limited fields).
 */
class UserPolicy extends Policy
{
    /**
     * Admin bypass with self-protection.
     *
     * Admins are unrestricted except they cannot:
     *  - delete themselves
     *  - manage their own site assignments
     *  - manage their own permission overrides
     *
     * Returning false from before() forces the specific ability method
     * to run, which will then deny the self-action.
     */
    public function before(User $user, string $ability, mixed ...$arguments): bool|null
    {
        $target = $arguments[0] ?? null;

        // Prevent an admin from locking themselves out of the system.
        if ($target instanceof User && $user->is($target)
            && in_array($ability, ['delete', 'manageSites', 'managePermissions'], true)
        ) {
            // Returning false skips the parent admin-bypass and forces
            // the concrete ability method below to execute (and deny).
            return false;
        }

        // Normal admin bypass for everything else.
        return parent::before($user, $ability);
    }

    /**
     * List users.
     */
    public function viewAny(User $actor): Response
    {
        return $this->allowIf(
            $actor->canManageUsers(),
            'You are not allowed to list users.',
        );
    }

    /**
     * View a single user.
     *
     * Users may always view themselves.
     */
    public function view(User $actor, User $user): Response
    {
        // Self-view is always allowed; otherwise require ManageUsers.
        return $this->allowIf(
            $actor->is($user) || $actor->canManageUsers(),
            'You are not allowed to view this user.',
        );
    }

    /**
     * Create a new user.
     *
     * Only admins may create users with the Admin role.
     *
     * @param  UserRole|string|null  $role  Optional role being assigned (from controller)
     */
    public function create(User $actor, UserRole|string|null $role = null): Response
    {
        if (! $actor->canManageUsers()) {
            return Response::deny('You are not allowed to create users.');
        }

        // Non-admins cannot elevate anyone to Admin.
        if ($this->isAdminRole($role) && ! $actor->isAdmin()) {
            return Response::deny('Only administrators can create admin users.');
        }

        return $this->allow();
    }

    /**
     * Update an existing user.
     *
     * Users may update themselves (controller should limit fields).
     * Only admins may assign the Admin role.
     *
     * @param  UserRole|string|null  $role  Optional new role being assigned
     */
    public function update(User $actor, User $user, UserRole|string|null $role = null): Response
    {
        // Self-update is allowed; otherwise require ManageUsers.
        if (! $actor->is($user) && ! $actor->canManageUsers()) {
            return Response::deny('You are not allowed to update this user.');
        }

        // Non-admins cannot assign the Admin role to anyone.
        if ($this->isAdminRole($role) && ! $actor->isAdmin()) {
            return Response::deny('Only administrators can assign the admin role.');
        }

        return $this->allow();
    }

    /**
     * Delete a user.
     *
     * Users cannot delete themselves (also guarded in before()).
     */
    public function delete(User $actor, User $user): Response
    {
        // Explicit self-check (before() already forces us here for admins).
        if ($actor->is($user)) {
            return Response::deny('You cannot delete your own account.');
        }

        return $this->allowIf(
            $actor->canManageUsers(),
            'You are not allowed to delete users.',
        );
    }

    /**
     * Manage a user’s site assignments.
     *
     * Users cannot change their own site list (also guarded in before()).
     */
    public function manageSites(User $actor, User $user): Response
    {
        if ($actor->is($user)) {
            return Response::deny('You cannot manage your own site assignments.');
        }

        return $this->allowIf(
            $actor->canManageUsers(),
            'You are not allowed to manage user sites.',
        );
    }

    /**
     * Manage a user’s permission overrides.
     *
     * Users cannot change their own overrides (also guarded in before()).
     */
    public function managePermissions(User $actor, User $user): Response
    {
        if ($actor->is($user)) {
            return Response::deny('You cannot manage your own permission overrides.');
        }

        return $this->allowIf(
            $actor->canManageUsers(),
            'You are not allowed to manage user permissions.',
        );
    }

    /**
     * Helper: is the given role the Admin role?
     */
    protected function isAdminRole(UserRole|string|null $role): bool
    {
        if ($role instanceof UserRole) {
            return $role === UserRole::Admin;
        }

        return $role === UserRole::Admin->value;
    }
}
