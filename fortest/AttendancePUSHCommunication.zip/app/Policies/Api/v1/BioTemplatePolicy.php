<?php

namespace App\Policies\Api\v1;

use App\Models\BioTemplate;
use App\Models\User;
use Illuminate\Auth\Access\Response;

/**
 * Authorization for BioTemplate resources (fingerprint, face, vein, …).
 *
 * Templates are device-scoped. Access follows the device’s site.
 *
 * Permissions used:
 *  - ReadEmployees or ReadAttendance → list / view
 *  - ManageEmployees or ManageDevices → delete
 */
class BioTemplatePolicy extends Policy
{
    /**
     * List bio templates.
     *
     * Controller should further filter by accessible devices/sites.
     */
    public function viewAny(User $user): Response
    {
        // Either employee or attendance readers may list biometric data.
        return $this->allowIf(
            $user->canReadEmployees() || $user->canReadAttendance(),
            'You are not allowed to list bio templates.',
        );
    }

    /**
     * View a single bio template.
     */
    public function view(User $user, BioTemplate $bioTemplate): Response
    {
        // Same permission gate as viewAny.
        if (! $user->canReadEmployees() && ! $user->canReadAttendance()) {
            return Response::deny('You are not allowed to view bio templates.');
        }

        // Template belongs to a device → enforce site access.
        return $this->authorizeDevice($user, $bioTemplate);
    }

    /**
     * Delete a bio template.
     *
     * Removing biometric data is a privileged action.
     */
    public function delete(User $user, BioTemplate $bioTemplate): Response
    {
        // Only users who can manage employees or devices may wipe biometrics.
        if (! $user->canManageEmployees() && ! $user->canManageDevices()) {
            return Response::deny('You are not allowed to delete bio templates.');
        }

        return $this->authorizeDevice($user, $bioTemplate);
    }
}
