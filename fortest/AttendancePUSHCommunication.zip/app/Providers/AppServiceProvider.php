<?php

namespace App\Providers;

use Illuminate\Foundation\DevCommands;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {

//        DevCommands::artisan('serve --host=0.0.0.0 --port=6060', 'server')->color('#ff6347');
        DevCommands::artisan('octane:start --server=frankenphp --host=0.0.0.0 --port=6060', 'server')->green();
        DevCommands::artisan('pail --timeout=0 -vv', 'logs')->blue();
//        DevCommands::artisan('pail --timeout=0 -v', 'logs')->blue();
        DevCommands::artisan('device:heartbeat --watch', 'device-heartbeat')->blue();
        DevCommands::artisan('device:commands-watch', 'pending-commands')->blue();
        DevCommands::artisan('device:commands-watch --all --limit=20', 'all-commands')->blue();
        DevCommands::artisan('queue:work rabbitmq --queue=operlog,photos,attendance,devices,default --timeout=300 --memory=512 -vv', 'queue')->yellow();
        DevCommands::artisan('reverb:start --host="0.0.0.0" --port=6061 --debug', 'reverb')->orange();
    }
}
