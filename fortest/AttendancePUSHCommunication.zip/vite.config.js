import { defineConfig } from 'vite';
import laravel from 'laravel-vite-plugin';
import { bunny } from 'laravel-vite-plugin/fonts';
import tailwindcss from '@tailwindcss/vite';

export default defineConfig({
    plugins: [
        laravel({
            input: ['resources/css/app.css', 'resources/js/app.js'],
            refresh: true,
            fonts: [
                bunny('Instrument Sans', {
                    weights: [400, 500, 600],
                }),
            ],
        }),
        tailwindcss(),
    ],
    server: {
        watch: {
            ignored: [
                '**/storage/framework/views/**',
                '**/bootstrap/cache/**',
                '**/storage/framework/cache/data/**',
                '**/storage/framework/sessions/**',
                '**/storage/framework/testing/**',
                '**/storage/framework/views/**',
                '**/storage/logs/**',
                '**/storage/app/**',
                '**/vendor/**',
                '**/node_modules/**',
            ],
        },
    },
});
